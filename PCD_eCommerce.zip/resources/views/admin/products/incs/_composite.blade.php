<div class="text-center">
    <button class="composite-object btn btn-xs btn-default" data-object-id="{{$row_object->id}}">
        <i class="fas fa-wrench"></i>
    </button>
</div>
