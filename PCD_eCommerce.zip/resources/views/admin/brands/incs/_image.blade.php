<div class="text-center">
    <image style="width: 100px;" src="{{ asset($row_object->image) }}" class="img-thumbnail" />
</div>