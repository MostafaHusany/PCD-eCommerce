@if($row_object->cost_type === 0)
<span class="badge badge-pill badge-primary">On Package</span>
@else 
<span class="badge badge-pill badge-warninng">Per Item</span>
@endif
