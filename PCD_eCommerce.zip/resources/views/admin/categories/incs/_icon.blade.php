@if(isset($row_object->icon))
<i style="font-size: 25px;" class="{{$row_object->icon}}"></i>
@else 
---
@endif