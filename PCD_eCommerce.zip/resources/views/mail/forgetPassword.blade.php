<h1>Forget password</h1>
   
Reseat Password
<a href="{{ route('reset.password.get',$token) }}">Forget password</a> 